package com.example.parrot.locationexample;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    // 0. Before starting, don't forget to ask for permission in the Manifest.xml file.

    // 1. Create a location manager
    //  - used to access the GPS on your phone
    LocationManager manager;

    // 2. A LocationListener is a function that detects when the
    // user position changes
    // Remember:  Your PHONE send the location to your APP
    // When your app receives the location, it will RUN the userLocationListener function
    // This is a CALLBACK!
    LocationListener userLocationListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 3. Initalize & configure the location manager variable
        this.manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);


        // 4. Write the code for the LISTENER (CALLBACK) function
        this.userLocationListener = new LocationListener() {

            // 4a. This function gets run when the phone receives a new location
            @Override
            public void onLocationChanged(Location location) {
                Log.d("JENELLE", "The user location changed!");
                Log.d("JENELLE","New location: " + location.toString());
                double x = location.getLatitude();
                double y = location.getLongitude();
                Log.d("JENELLE", "Location is: " + x + "," + y);
            }

            // 4b. IGNORE THIS FUNCTION!
            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            // 4b. IGNORE THIS FUNCTION!
            @Override
            public void onProviderEnabled(String provider) {

            }

            // 4b. IGNORE THIS FUNCTION!
            @Override
            public void onProviderDisabled(String provider) {

            }
        };


        // 5. Configure the app to ASK for permission to get user location.
        // In Android, there are 2 different ways to ask for permissions:
        //  * Method 1: For phones that are before Marshmallow (before API 23)
        //  * Method 2: For phones AFTER Marshmallow (after API 23)
        // -----------

        // 5a. This is for phones BEFORE Marshmallow
        if (Build.VERSION.SDK_INT < 23) {

            this.manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this.userLocationListener);

        }
        // 5b.  This is for phones AFTER Marshmallow
        else {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // Show the popup box! ask for permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                // Do this code if the user PREVIOUSLY gave us permission to get location.
                // (ie: You already have permission!)
                this.manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this.userLocationListener);

            }

        }

    }




    // 6. More code needed for asking for permissions!
    // -- This code decides what to do if the user clicks on ALLOW vs. DENY in the permission popup box
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        // 4a.  Show the popup box
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        // 4b. If the person clicks ALLOW, then get the person's location
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                // 4c. Same as manager.startUpdatingLocations in IOS
                // -- In code below, you are telling the app to use the GPS to get location.
                // -- When you get the location, run the userLocationListerer
                this.manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,0, userLocationListener);
            }
        }
    }


}



